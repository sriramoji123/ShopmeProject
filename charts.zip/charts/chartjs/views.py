# from django.http import JsonResponse
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

from django.shortcuts import render
from django.views.generic import View

from rest_framework.views import APIView
from rest_framework.response import Response

class HomeView(View):
	def get(self, request, *args, **kwargs):
		return render(request, 'chartjs/index.html')



df=pd.read_csv("C:/Users/Ramoji/Desktop/data.csv")
labels1=[]
def a():
    first=df.iloc[:,1]
    for i in first:
        labels1.append(i)
b=labels1[:4]
####################################################

## if you don't want to user rest_framework

# def get_data(request, *args, **kwargs):
#
# data ={
#			 "sales" : 100,
#			 "person": 10000,
#	 }
#
# return JsonResponse(data) # http response


#######################################################

## using rest_framework classes

class ChartData(APIView):
    
    
	def get(self, request, format = None):
     
		df=pd.read_csv("C:/Users/Ramoji/Desktop/data.csv")
		labels1=[]
		labels2=[]
		first=df.iloc[:,1]
		second=df.iloc[:,2]
		for j in second:
			labels2.append(j)
		labels2=labels2[0:4]
		for i in first:
			labels1.append(i)
		labels1=labels1[0:4]
		labels = [
			'January',
			'February',
			'March',
			'April',
			'May',
			'June',
			'July'
			]
		chartLabel = "my data"
		chartdata = [0, 10, 5, 2, 20, 30, 45]
		labels=labels1
		chartdata=labels2
		data ={
					"labels":labels,
					"chartLabel":chartLabel,
					"chartdata":chartdata,
			}
		return Response(data)

    